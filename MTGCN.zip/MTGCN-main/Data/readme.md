### Dataset
* sa_task.csv: The columns in this file are sentence, sentiment label, hatespeech label, and sarcasm label.
* ei_task.csv: The columns in this file are sentence and emotion column.
* Sentiment Labels: {"pos": positive, "neg": negative}.
* Emotion Labels: {"happy", "sad", "fear" ,"anger"}.
* Hatespeech Labels: {"yes", "no"}.
* Sarcasm Labels: {"yes", "no"}.
